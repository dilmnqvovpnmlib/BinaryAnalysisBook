#include <stdio.h>

int main(){
  int a;
  a = 0;
  if(a != 0){
    printf("hacked!\n");
  }else{
    printf("failed!\n");
  }
  return 0;
}
