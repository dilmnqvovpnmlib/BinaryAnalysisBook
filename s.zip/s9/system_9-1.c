#include <stdlib.h>

int main(){
  system("/bin/ls");
  return 0;
}
