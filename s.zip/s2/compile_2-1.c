#include <stdio.h>

int main() {
  printf("%d\n", 2 + 3);
  return 0;
}
